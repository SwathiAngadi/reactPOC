import React from 'react';
import {  Route,
  NavLink,
  HashRouter } from 'react-router-dom';

//Component
import Home from './components/Home';
import NewHotel from './components/NewHotel';
import Update from './components/Update';
import Filter from './components/Filter';
import Delete from './components/Delete';
import logo from './logo.svg';
const Router = () => {
    return (
        <HashRouter> 
            <div>
            <nav class="navbar navbar-expand-sm bg-light">
            <img src={logo} className="logo" alt="logo" />
            <a href ="/"> <h2 class="text-info">HOTEL PROJECT</h2></a>
            <div className="collapse navbar-collapse">
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/">HOME</a>
                </li>
                <li class="nav-item">
                    <NavLink to="/NewHotel" class="nav-link">NEW HOTEL</NavLink>
                </li>
                <li class="nav-item dropdown">
                
                <a className="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">MANAGE EXISTING </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li  class="nav-item navSub "><NavLink to="/Update" class="nav-link">UPDATE</NavLink></li>
                    <li  class="nav-item navSub "><NavLink to="/Delete" class="nav-link">DELETE</NavLink> </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <NavLink to="/Filter"  class="nav-link">FILTER </NavLink>
                </li>
                </ul>
                </div>
                </nav> 
             
                <div className="main">  
                <Route path="/" exact component={Home} />
                <Route path = "/NewHotel"  component={NewHotel}/>
                <Route path = "/Update"  component={Update}/>  
                <Route path = "/Delete"  component={Delete}/>            
                <Route path="/Filter" component={Filter}/>
                </div>
                <footer>
                    <div class="footer1"> 
                    <p className="text-center"> ©2019 React Hotel Project. All Rights Reserved</p>
                    <p className="text-muted text-center">Designed & Created by &nbsp; Swathi</p>
                    </div>
                </footer>
            </div>
            </HashRouter>
      
    )
}

export default Router
