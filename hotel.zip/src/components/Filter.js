import React, { Component } from "react";
import axios from 'axios';
import InputRange from 'react-input-range';

class Filter extends Component {
    state = {
        minvalue: 3,
        maxvalue: 8,
        data:''
      };
    componentDidMount () {
        return axios.get("http://localhost:8090/example/v1/hotels?page=0&size=100").then (res =>{
            console.log(res);
        return this.setState({data: res.data.content});       
        });
    }
    handleChange= (event) =>{
        this.setState({value: event.target.value});
      }
   
    render() {
      
        return (
           
                <div className="container"> 
                <h3><i> Filtering of Hotels Information based on their ratings...!!!</i></h3>
                <br/>
                    <div className="rating">
                        <div className="ratingMin">
                            <input type="range"  min={0} max={5} value={this.state.minvalue} onChange={event => this.handleChange(event)} id="minVal"/>
                            <label> Min Rating (3)</label>
                        </div>
                        <div className="ratingMax">
                            <input type="range" min={5} max={10} value={this.state.maxvalue}  onChange={event => this.handleChange(event)} id="maxVal"/>
                            <label> Max Rating(8)</label>
                        </div>
                        <br/>
                    <br/>
                    </div>
             
                    {this.state.data ? <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">City</th>
                        <th scope="col">Rating</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                     this.state.data.map ( hotels => {
                        if(hotels.rating >this.state.minvalue && hotels.rating < this.state.maxvalue)
                        return (
                            <tr>
                                <td>{hotels.id}</td>
                                <td>{hotels.name}</td>
                                <td>{hotels.description} </td>
                                <td>{hotels.city}</td>
                                <td>{hotels.rating}</td>
                            </tr>
                        )
                    })
                    }  
                    </tbody>
                </table> :null}             
            </div>
        )
    }
}


export default Filter;