import React, { Component } from "react";
import axios from 'axios';

class NewHotel extends Component {
    state = {
        name: '',
        description: '',
        city: '',
        rating: '',
        flag: false		   
    }
    
    handleChange(event) {
        this.setState({ [event.target.id]: event.target.value });
    };
    
    Add = () => {
        console.log(this.state);
        axios.post('http://localhost:8090/example/v1/hotels', {        
            "name": this.state.name,
            "description": this.state.description,
            "city": this.state.city,          
            "rating": this.state.rating       
        }).then (res =>{
            this.setState({flag:true});
        return {
            data: res.data           
        }
        })
    };

    render() {
      
        return (
            <div>
               
                <div className="container">
                <h3><i> In this section you can add new Hotel Information </i></h3>
                <p> Please fill all the fields</p>
                <p> Rating can be given from 0-10 *</p>
                <form className="form-horizontal addform">
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> Name</label>
                    <input type="text" className="form-control col-sm-9" id="name" onChange={event => this.handleChange(event)}/>
                </fieldset>
                <fieldset  className="form-group ">
                    <label className="control-label col-sm-3"> Description</label>
                    <textarea type="text" className="form-control col-sm-9" id="description" onChange={event => this.handleChange(event)}/>
                </fieldset>
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> City</label>
                    <input type="text" className="form-control col-sm-9" id="city" onChange={event => this.handleChange(event)}/>
                </fieldset>
              
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> Rating</label>
                    <input type="text" className="form-control col-sm-9" id ="rating" onChange={event => this.handleChange(event)}/>
                </fieldset>
                </form>
                <button className="btn btn-info listBtn" onClick={this.Add}> ADD HOTEL </button>             
                {this.state.flag ? <p className="successMsg">Hotel {this.state.id} added successfully</p>: null}      
                </div>  
                
            </div>
        )
    }
}


export default NewHotel;