import React, { Component } from "react";
import axios from 'axios';

class Update extends Component {
    state = {
        uname: '',
        udescription: '',
        ucity: '',
		uid: '',
        urating: '',
        uflag: false,
        err: false		   
    }
    
    handleChange(event) {
        this.setState({ [event.target.id]: event.target.value });
    };
    
    Add = () => {
        console.log(this.state);
        var id = this.state.uid
        this.setState({err:true});
        axios.put('http://localhost:8090/example/v1/hotels/'+ id, {        
            "name": this.state.uname,
            "description": this.state.udescription,
            "city": this.state.ucity,
            "id": this.state.uid,
            "rating": this.state.urating       
        }).then (res =>{
            console.log(res);
            this.setState({uflag:true});
            this.setState({uid:id});
            this.setState({err:false});
        return {
            data: res.data           
        }
        })
        
    };

    render() {
      
        return (
            <div className="container">
                <h3> Edit the information of reqired hotels by mentioning particular Id</h3>
                   <h5><i> Remember you can only the edit information of the hotel which you have already added...!!!</i></h5>
                <div className="container">
                <form className="form-horizontal addform">
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> Name</label>
                    <input type="text"  className="form-control col-sm-9" id="uname" onChange={event => this.handleChange(event)}/>
                </fieldset>
                <fieldset  className="form-group ">
                    <label className="control-label col-sm-3"> Description</label>
                    <textarea type="text"  className="form-control col-sm-9" id="udescription" onChange={event => this.handleChange(event)}/>
                </fieldset>
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> City</label>
                    <input type="text"  className="form-control col-sm-9" id="ucity" onChange={event => this.handleChange(event)}/>
                </fieldset>
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> Hotel ID</label>
                    <input type="number"  className="form-control col-sm-9" id="uid" onChange={event => this.handleChange(event)}/>
                </fieldset>
                <fieldset className="form-group ">
                    <label className="control-label col-sm-3"> Rating</label>
                    <input type="text"  className="form-control col-sm-9" id ="rating" onChange={event => this.handleChange(event)}/>
                </fieldset>               
                </form>
                <button class="btn btn-info" onClick={this.Add}> UPDATE HOTEL </button>    
                </div>  
                {this.state.uflag ? <p className="successMsg">Hotel {this.state.id} inforamation Updated successfully</p>: null}    
                {this.state.err ? <p className="errMsg"> Hotel ID entered in invalid, Please enter the Id of the Hotel for which you want to change the Information</p>:null}  
            </div>
        )
    }
}


export default Update;