import React, { Component } from "react";
import axios from 'axios';

class Home extends Component {
    state ={
        data: '',
        hotel:''
    }

    listAll = () => {
        return axios.get("http://localhost:8090/example/v1/hotels?page=0&size=100").then (res =>{
            console.log(res);
        return this.setState({data: res.data.content});       
        });
    };
    hotelInfo=() => {
        var id = document.getElementById("search").value;
        axios.get("http://localhost:8090/example/v1/hotels/"+id).then(res => {
            console.log(res);
            return this.setState({hotel: res.data}); 
        });
    }
    render() {
      
        return (
            <div>
                <div class="container">
                <h2>Welcome to Hotel Application</h2>
                <br/>
                <br/>
                <h4><i> This is a Single Page Application constructed using React where you can add hotel information, edit update and also you can remove the hotel information.</i></h4>
                <br/>
                <br/>
                <hr/>
                <h5> Let's get started by fetching the information of the hotel...</h5>          
              
                <input type="text" placeholder="Search by Id.." id="search" class="form-control col-sm-3" />
                <button type="submit" class="hotelbtn" onClick={this.hotelInfo}><i class="fa fa-search"></i></button>
                {this.state.hotel ? <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">City</th>
                        <th scope="col">Rating</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>{this.state.hotel.id}</td>
                        <td> {this.state.hotel.name}</td>
                        <td> {this.state.hotel.description}</td>
                        <td>{this.state.hotel.city}</td>
                        <td>{this.state.hotel.rating}</td>
                    </tr>
                    </tbody>
                    </table> : null 
                 }
                <hr/>
                <h6> Click on List Hotels to view all the Hotels</h6>
                <button class="btn btn-info text-uppercase listBtn" onClick={this.listAll}> List Hotels </button>
               
               { this.state.data ?<table class="table">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">City</th>
                        <th scope="col">Rating</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.data && this.state.data.map(data => {
                            return (
                                <tr>
                                    <td>{data.id}</td>
                                   <td> {data.name}</td>
                                   <td> {data.description}</td>
                                    <td>{data.city}</td>
                                    <td>{data.rating}</td>
                                </tr>
                            );
                        })
                        }
                    </tbody>
                </table> :null}
                </div>       
            </div>
        )
    }
}


export default Home;