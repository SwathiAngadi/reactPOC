import React, { Component } from "react";
import axios from 'axios';

class Delete extends Component {
    state = {
        did: '',
        dflag: false,
        id:'',
        err:''	   
    }
    
    handleChange(event) {
        this.setState({ [event.target.id]: event.target.value });
    };
    
    Add = () => {
        this.setState({err:true})
        var id = this.state.did;
        axios.delete('http://localhost:8090/example/v1/hotels/'+ id).then (res =>{
            console.log(res);
            this.setState({dflag:true});
            this.setState({id:id});
            this.setState({err:false});
        return {
            data: res.data           
        }
        })
        
    };

    render() {
      
        return (
            <div>
                <div className="container">
                    <h3><i> If you want to delete the information of any Hotel, Please enter the Id of that hotel</i></h3>
                    <fieldset className="form-group addform">
                        <label className="control-label col-sm-3"> Hotel ID</label>
                        <input type="number" className="form-control" id="did" onChange={event => this.handleChange(event)}/>
                    </fieldset>
                    <button class="btn btn-info" onClick={this.Add}> DELETE HOTEL </button>  
                    {this.state.dflag ? <p className="successMsg"> Information of the Hotel {this.state.id} Deleted successfully</p>: null}   
                    {this.state.err ? <p className="errMsg"> Hotel ID entered in invalid, Please enter the correct Id of the Hotel </p>:null}
                </div>
            </div>  
        )
    }
}


export default Delete;